###
###

.pkgname <- "BSgenome.Osativa.MSU.xzg"

.seqnames <- c("Chr1","Chr2","Chr3","Chr4","Chr5","Chr6","Chr7","Chr8","Chr9","Chr10","Chr11","Chr12")

.circ_seqs <- c("ChrC", "ChrM")

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Oryza sativa",
        common_name="Rice",
        provider="MSU",
        provider_version="MSU7",
        release_date="2011-10-31",
        release_name="Oryza sativa full genome (MSU7)",
        source_url="https://rapdb.dna.affrc.go.jp/download/irgsp1.html",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Osativa"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

